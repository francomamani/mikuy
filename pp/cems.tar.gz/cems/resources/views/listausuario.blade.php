@extends('plantillaadmin')

@section('seccion')
       @if(session('mensaje'))
       <div class="alert alert-success text-center">
        {{session('mensaje')}}
       
        <a href="{{ route('listausuario') }}" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

       </div>

       @endif
      
    <h1>LISTA DE USUARIOS</h1>


<br>
 <div class="table-responsive">
                   <table class="table ">
                      <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">USUARIO</th>
      <th scope="col">TIPO</th>
      <th scope="col">ELIMINAR</th>
    </tr>
  </thead>
  <tbody>
  @foreach($materialu as $item)
    <tr>
      <th scope="row">{{$item->id}}</th>
      <td>{{$item->name}}</td>
      <td>{{$item->rol}}</td>

      <form action="{{route('eliminau',$item)}}" method="POST">
                 @method('DELETE')
                 @csrf

                 <td><button type = "submit"class="btn btn-danger btn-sm" type="button">ELIMINAR</button></td>
                </form>
    </tr>
    @endforeach()  
  </tbody>
</table>
</div>
 


@endsection