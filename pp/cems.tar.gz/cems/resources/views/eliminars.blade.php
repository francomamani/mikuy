@extends('plantillaadmin')

@section('seccion')
       @if(session('mensaje'))
       <div class="alert alert-success text-center">
        {{session('mensaje')}}
       
        <a href="{{ route('eliminars') }}" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

       </div>

       @endif
       <br>

      <br>

<div  ALIGN="right">
  <form action="{{route('nuevos')}}" method="POST">
  
  @csrf 
  <div class="col-lg-6",>
   <div class="input-group card-footer text-center">
      <input type="text" class="form-control"name="material" placeholder="Nombre del nuevo material" >
      <span class="input-group-btn">
        <button type = "submit"class="btn btn-dark" type="button">AGREGAR</button>
      </span>
    </div>
  </div>
</div>
    
  </form>
  </div>

    


<br>
 <div class="table-responsive">
                   <table class="table ">
                      <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Material</th>
      <th scope="col">Eliminar</th>
    </tr>
  </thead>
  <tbody>
  @foreach($materials as $item)
    <tr>
      <th scope="row">{{$item->id}}</th>
      <td>{{$item->material}}</td>
      <form action="{{route('eliminas',$item)}}" method="POST">
                 @method('DELETE')
                 @csrf

                 <td><button type = "submit"class="btn btn-danger btn-sm" type="button">ELIMINAR</button></td>
                </form>
    </tr>
    @endforeach()  
  </tbody>
</table>
</div>
 


@endsection