@extends('plantillaadmin')


@section('seccion')
<br><br>
@if(session('mensaje'))
 <div class=" alert alert-success">
  {{session('mensaje')}}

  <a href="{{ route('instalarbd') }}" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

 </div >
 
@endif


<form action="importarmesam" method="post" enctype="multipart/form-data" target="_blank">
@csrf 
  <p>

    Sube un archivo:

    <input type="file" name="file">

    <input type="submit" value="Enviar datos">

  </p>

</form>

   
@endsection