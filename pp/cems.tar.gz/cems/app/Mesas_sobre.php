<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mesas_sobre extends Model
{
    public $timestamps = false;
    protected $table = "mesas_sobres";
    protected $primaryKey  = "CodigoMesa";
    protected $fillable = [
        "departamento",
"provincia",
"municipio",
"asiento",
"distrito",
"zona",
"nombre_recinto",
"circunscripcion",
"nombres",
"primer_apellido",
"segundo_apellido",
"numero_documento",
"numero_telefono",
"recepcionado",
"usuario",
"fecha"

    ];
}
