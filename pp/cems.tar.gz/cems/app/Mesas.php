<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Mesas extends Model
{
    public $timestamps = false;
    protected $table = "mesas";
    protected $primaryKey  = "CodigoMesa";
    protected $fillable = [
        "departamento",
"provincia",
"municipio",
"asiento",
"distrito",
"zona",
"nombre_recinto",
"circunscripcion",
"nombres",
"primer_apellido",
"segundo_apellido",
"numero_documento",
"numero_telefono",
"recepcionado",
"usuario",
"fecha"
    ];
}
