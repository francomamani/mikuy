<?php

namespace App\Imports;

use App\mesas;
use Maatwebsite\Excel\Concerns\ToModel;

class Importm implements ToModel
{
    /**
    * @param array $row
    *
    * @return \Illuminate\Database\Eloquent\Model|null
    */
    public function model(array $row)
    {
        return new mesas([
            'CodigoMesa' =>$row[0],
            'departamento'=>$row[1],
            'provincia' =>$row[2],
            'municipio'=>$row[3],
            'asiento'=>$row[4],
            'distrito'=>$row[5],
            'zona'=>$row[6],
            'nombre_recinto'=>$row[7],
            'circunscripcion'=>$row[8],
            'nombres'=>$row[9],
            'primer_apellido'=>$row[10],
            'segundo_apellido'=>$row[11],
            'numero_documento'=>$row[12],
            'numero_telefono'=>$row[13],
            'recepcionado'=>$row[14],
            'usuario'=>$row[15],
            'fecha'=>$row[16]
        ]);





        
    }
}
