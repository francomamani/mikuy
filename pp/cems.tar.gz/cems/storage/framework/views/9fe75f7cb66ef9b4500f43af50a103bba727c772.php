<?php $__env->startSection('seccion'); ?>
<br><br>
<?php if(session('mensaje')): ?>
 <div class=" alert alert-success">
  <?php echo e(session('mensaje')); ?>


  <a href="<?php echo e(route('instalarbd')); ?>" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

 </div >
 
<?php endif; ?>


<form action="importarmesam" method="post" enctype="multipart/form-data" target="_blank">
<?php echo csrf_field(); ?> 
  <p>

    Sube un archivo:

    <input type="file" name="file">

    <input type="submit" value="Enviar datos">

  </p>

</form>

   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillaadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\cems2\resources\views/instalarbd.blade.php ENDPATH**/ ?>