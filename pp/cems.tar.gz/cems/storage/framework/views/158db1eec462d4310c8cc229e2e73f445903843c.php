<?php $__env->startSection('seccion'); ?>
<br>
  <h5>ESTA MALETA A UN NO FUE ENTREGADA<h5>
        <br><br>
        <div class="card">
            <div class="card-header">
                <h3>MALETA</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <tbody>
                        <tr>
                            <td>Codigo de mesa:</td>
                            <td><?php echo e($maleta->CodigoMesa); ?></td>
                        </tr>
                        <tr>
                            <td>nombre departamento:</td>
                            <td><?php echo e($maleta->departamento); ?></td>
                        </tr>
                        <tr>
                            <td>nombre provincia:</td>
                            <td><?php echo e($maleta->provincia); ?></td>
                        </tr>
                        <tr>
                            <td>nombre municipio:</td>
                            <td><?php echo e($maleta->municipio); ?></td>
                        </tr>
                        <tr>
                            <td>asiento electoral:</td>
                            <td><?php echo e($maleta->asiento); ?></td>
                        </tr>
                        <tr>
                            <td>nombre distrito:</td>
                            <td><?php echo e($maleta->distrito); ?></td>
                        </tr>
                        <tr>
                            <td>nombre zona:</td>
                            <td><?php echo e($maleta->zona); ?></td>
                        </tr>
                        <tr>
                            <td>nombre recinto</td>
                            <td><?php echo e($maleta->nombre_recinto); ?></td>
                        </tr>
                        <tr>
                            <td>circunscripcion:</td>
                            <td><?php echo e($maleta->circunscripcion); ?></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
           
        </div>

 <?php $__env->stopSection(); ?>   

<?php echo $__env->make('plantillaadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\cems2\resources\views/faltab.blade.php ENDPATH**/ ?>