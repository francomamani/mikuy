<?php $__env->startSection('seccion'); ?>
<br><br>
<?php if(session('mensaje')): ?>
 <div class=" alert alert-success">
  <?php echo e(session('mensaje')); ?>


  <a href="<?php echo e(route('reportes')); ?>" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

 </div >
<?php endif; ?>

<h3 ALIGN="center">REPORTE DE SOBRES "A" RECEPCIONADOS<h3>
<br>
<div class="input-group card-footer text-center">
<h4>Sobres "A" recepcionados:</h4>
<samp><h3><?php echo e($contador1); ?></h3></samp>
</div>
<div class="input-group card-footer text-center">
<h4>Sobres "A" que faltan recepcionar:</h4>
<samp><h3><?php echo e($falta); ?></h3></samp>


</div>
  <br>
  <div ALIGN="center"  >
  <button  onclick="location.href='<?php echo e(route('exportarso')); ?>'" ><img src="<?php echo e(asset('Excel.jpg')); ?>" />Exportar  Sobres"A" recepcionados  y no recepcionados</button>
  <br><br><br>
  
  </div> 
    
  
   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillasobre', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\cems2\resources\views/reportes.blade.php ENDPATH**/ ?>