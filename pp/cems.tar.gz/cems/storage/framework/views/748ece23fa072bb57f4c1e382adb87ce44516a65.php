<?php $__env->startSection('seccion'); ?>

       <?php if(session('mensaje')): ?>
       <div class="alert alert-success text-center">
        <?php echo e(session('mensaje')); ?>

       
        <a href="<?php echo e(route('listausuario')); ?>" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

       </div>

       <?php endif; ?>
      

       <form action="<?php echo e(route('importarmesam)); ?>" method="POST" enctype="multipart/form-dat">
                 <?php echo csrf_field(); ?>

                 <td><button type = "submit"class="btn btn-danger btn-sm" type="button">ELIMINAR</button></td>

                    <input type="file" name="file" ></input>
             
             <button>Importar mesas </button>
             
                </form>




<?php $__env->stopSection(); ?>       
<?php echo $__env->make('plantillaadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> ?><?php /**PATH D:\proyectos\cems2\resources\views/configuracionBD.blade.php ENDPATH**/ ?>