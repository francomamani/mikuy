<?php $__env->startSection('seccion'); ?>
       <?php if(session('mensaje')): ?>
       <div class="alert alert-success text-center">
        <?php echo e(session('mensaje')); ?>

       
        <a href="<?php echo e(route('eliminarm')); ?>" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

       </div>

       <?php endif; ?>
       <br>
      
      <br>

<div  ALIGN="right">
  <form action="<?php echo e(route('nuevom')); ?>" method="POST">
  
  <?php echo csrf_field(); ?> 
  <div class="col-lg-6",>
   <div class="input-group card-footer text-center">
      <input type="text" class="form-control"name="material" placeholder="Nombre del nuevo material" >
      <span class="input-group-btn">
        <button type = "submit"class="btn btn-dark" type="button">AGREGAR</button>
      </span>
    </div>
  </div>
</div>
    
  </form>
  </div>

    


<br>
 <div class="table-responsive">
                   <table class="table ">
                      <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Material</th>
      <th scope="col">Eliminar</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $materialm; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($item->id); ?></th>
      <td><?php echo e($item->material); ?></td>
      <form action="<?php echo e(route('eliminam',$item)); ?>" method="POST">
                 <?php echo method_field('DELETE'); ?>
                 <?php echo csrf_field(); ?>

                 <td><button type = "submit"class="btn btn-danger btn-sm" type="button">ELIMINAR</button></td>
                </form>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
  </tbody>
</table>
</div>
 


<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillaadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\cems2\resources\views/eliminarm.blade.php ENDPATH**/ ?>