<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', 'pagecontroller@inicio' )->name('inicio');

Auth::routes();

Route::get('/home', 'HomeController@index');


Route::post('login','Auth\LoginController@login')->name('login');
Route::post('logoaut','Auth\LoginController@logoaut')->name('logoaut');









Route::get('sobre','pagecontroller@sobre')-> name('sobre');
Route::get('sobrei','pagecontroller@sobrei')-> name('sobrei');
Route::post('buscarsobre','pagecontroller@buscarsobre')->name('buscarsobre');
Route::get('/reportes','pagecontroller@reportes')-> name('reportes');
Route::post('/buscars','pagecontroller@buscars')-> name('buscars');
Route::get('sobreb','pagecontroller@sobreb')-> name('sobreb');
Route::get('/reportescodigo','pagecontroller@reportescodigo')-> name('reportescodigo');
Route::get('/reportescodigoadmin','pagecontroller@reportescodigoadmin')-> name('reportescodigoadmin');




Route::get('/maleta','pagecontroller@maleta')-> name('maleta');
Route::post('buscarmesa','pagecontroller@buscarMesa')->name('buscarMesa');
Route::get('maletai','pagecontroller@maletai')-> name('maletai');
Route::post('/buscar','pagecontroller@buscar')-> name('buscar');
Route::get('/reporte','pagecontroller@reporte')-> name('reporte');
Route::get('/reportem','pagecontroller@reportem')-> name('reportem');
Route::post('/buscarm','pagecontroller@buscarm')-> name('buscarm');
Route::post('/maletab','pagecontroller@buscarm')-> name('maletab');
Route::get('/reportemcodigo','pagecontroller@reportemcodigo')-> name('reportemcodigo');
Route::get('/reportemcodigoadmin','pagecontroller@reportemcodigoadmin')-> name('reportemcodigoadmin');


Route::get('/edicion','pagecontroller@edicion')-> name('edicion');

Route::get('/agregarm','pagecontroller@agregarm')-> name('agregarm');
Route::post('/nuevom','pagecontroller@nuevom')-> name('nuevom');
Route::get('/eliminarm','pagecontroller@eliminarm')-> name('eliminarm');
Route::delete('/eliminam/{id}','pagecontroller@eliminam')-> name('eliminam');


Route::get('/eliminars','pagecontroller@eliminars')-> name('eliminars');
Route::delete('/eliminas/{id}','pagecontroller@eliminas')-> name('eliminas');
 
Route::get('/agregars','pagecontroller@agregars')-> name('agregars');
Route::post('/nuevos','pagecontroller@nuevos')-> name('nuevos');


Route::post('/guardarm','pagecontroller@guardarm')-> name('guardarm');
Route::post('/guardars','pagecontroller@guardars')-> name('guardars');


Route::get('/ingresousuario','pagecontroller@ingresousuario')-> name('ingresousuario');

Route::post('/buscarusuario','pagecontroller@buscarusuario')-> name('buscarusuario');
Route::get('/agregarusuario','pagecontroller@agregarusuario')-> name('agregarusuario');
Route::post('/guardarusuario','pagecontroller@guardarusuario')-> name('guardarusuario');
Route::delete('/eliminau/{id}','pagecontroller@eliminau')-> name('eliminau');
Route::get('/listausuario','pagecontroller@listausuario')-> name('listausuario');

Route::get('/administrador','pagecontroller@administrador')-> name('administrador');


Route::get('maletaiadmin','pagecontroller@maletaiadmin')-> name('maletaiadmin');
Route::get('/maletadmin','pagecontroller@maletaadmin')-> name('maletaadmin');
Route::post('buscar-mesaadmin','pagecontroller@buscarMesaadmin')->name('buscarMesaadmin');
Route::get('/reportemadmin','pagecontroller@reportemadmin')-> name('reportemadmin');
Route::post('/buscarmadmin','pagecontroller@buscarmadmin')-> name('buscarmadmin');
Route::get('/maletabadmin','pagecontroller@buscarm')-> name('maletabadmin');
Route::post('/guardarmadmin','pagecontroller@guardarmadmin')-> name('guardarmadmin');

Route::get('sobreiadmin','pagecontroller@sobreiadmin')-> name('sobreiadmin');
Route::get('sobreadmind','pagecontroller@sobreadmin')-> name('sobreadmin');
Route::post('buscarsobreadmin','pagecontroller@buscarsobreadmin')->name('buscarsobreadmin');
Route::get('sobreadmin','pagecontroller@sobreadmin')-> name('sobreadmin');
Route::get('/reportesadmin','pagecontroller@reportesadmin')-> name('reportesadmin');
Route::post('/buscarsadmin','pagecontroller@buscarsadmin')-> name('buscarsadmin');
Route::get('sobrebadmin','pagecontroller@sobrebadmin')-> name('sobrebadmin');
Route::post('/guardarsadmin','pagecontroller@guardarsadmin')-> name('guardarsadmin');

Route::get('faltam','pagecontroller@faltam')-> name('faltam');
Route::post('/buscarfm','pagecontroller@buscarfm')-> name('buscarfm');
Route::get('faltab','pagecontroller@faltab')-> name('faltab');
Route::get('faltas','pagecontroller@faltas')-> name('faltas');
Route::post('/buscarfs','pagecontroller@buscarfs')-> name('buscarfs');
Route::get('faltabs','pagecontroller@faltab')-> name('faltabs');


Route::put('/actualisarm','pagecontroller@actualisarm')-> name('actualisarm');
Route::put('/actualisarmadmin','pagecontroller@actualisarmadmin')-> name('actualisarmadmin');
Route::put('/actualisars','pagecontroller@actualisars')-> name('actualisars');
Route::put('/actualisarsadmin','pagecontroller@actualisarsadmin')-> name('actualisarsadmin');


Route::get('exportar','pagecontroller@exportar')->name('exportar');
Route::get('exportars','pagecontroller@exportars')->name('exportars');
Route::get('exportarme','pagecontroller@exportarme')->name('exportarme');
Route::get('exportarso','pagecontroller@exportarso')->name('exportarso');

Route::get('instalarbd','pagecontroller@instalarbd')->name('instalarbd');
Route::post('importarmesam','pagecontroller@importarmesam')->name('importarmesam');



