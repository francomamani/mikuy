<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Maleta extends Model
{
    public $timestamps = false;
    protected $table = "maletas";
    protected $primaryKey  = "id";
    protected $fillable = [
        
	"CodigoMesa",  
        "material",            
        "obcervaciones"
      
    ];
}
