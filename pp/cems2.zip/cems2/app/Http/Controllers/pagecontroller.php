<?php

namespace App\Http\Controllers;


use App\Mesas;
use App\Mesas_sobre;
use App\Material;
use App\Maleta;
use App\Material1;
use App\User;
use App\Sobre;
use Maatwebsite\Excel\Facades\Excel;
use App\Exports\Exportar;
use App\Exports\Exportars;
use App\Exports\Exportarme;
use App\Exports\Exportarso;
use App\Imports\Importm;
use Illuminate\Support\Facades\View;



use Illuminate\Http\Request;

class pagecontroller extends Controller
{
   public function inicio(){
    return view('auth.login');
    
   }
   
   public function administrador(){
    
    
    return view('administrador');     

  }
   public function sobre(){
    return view('sobre');
   }
   public function sobreadmin(){
    return view('sobreadmin');
   }

  
    
   public function maletai(){

          $m=0;
          
            return view('maletai',compact('m'));
     }
   

     public function sobrei(){

      $s=0;
      return view('sobrei',compact('s'));
}


public function sobreiadmin(){

  
  $s=0;
            return view('sobreiadmin',compact('s'));
}

public function maletaiadmin(){

  $m=0;
  return view('maletaiadmin',compact('m'));

  
}



     
   public function maleta( ){

      

      return view('maleta');
   }
 
   public function maletaadmin( ){

      

    return view('maletadmin');
    }

  public function faltab(){

    return view('faltab');
  }

  public function faltabs(){

    return view('faltabs');
  }


  public function reportemcodigo(){

    return view('reportemcodigo');
  }

  public function reportescodigo(){

    return view('reportescodigo');
  }

  public function reportemcodigoadmin(){

    return view('reportemcodigoadmin');
  }


  public function reportescodigoadmin(){

    return view('reportescodigoadmin');
  }


  public function instalarbd(){

    return view('instalarbd');
  }
  
   public function buscarMesa()
    {
        $codigoMesa = (int)request()->input('CodigoMesa');
        $existe = Mesas::where('CodigoMesa',"=", $codigoMesa)->exists();
        $existe1 =Maleta::where('CodigoMesa',"=", $codigoMesa)->exists();
        $mesa = Mesas::find($codigoMesa);
        $material=Material::all();
        $response = [
            'maleta' => $mesa,
            'existe' => $existe,
             'existe1'=>$existe1,
            'material'=>$material
          
        ];
        
        return view('maleta', $response);
       
    }


    public function buscarMesaadmin()
    {
        $codigoMesa = (int)request()->input('CodigoMesa');
        $existe = Mesas::where('CodigoMesa',"=", $codigoMesa)->exists();
        $existe1 = Maleta::where('CodigoMesa',"=", $codigoMesa)->exists();
        $mesa = Mesas::find($codigoMesa);
        $material=Material::all();
        $response = [
            'maleta' => $mesa,
            'existe' => $existe,
             'existe1'=>$existe1,
            'material'=>$material
           
        ];
      
        return view('maletaadmin', $response);
      }
      public function buscarsobre()
      {
          $codigoMesa = (int)request()->input('CodigoMesa');
          $nombre= request()->input('nombre');
          $existe = Mesas::where('CodigoMesa',"=", $codigoMesa)->exists();
          $existe1 =Sobre::where('CodigoMesa',"=", $codigoMesa)->exists();
          $mesa = Mesas::find($codigoMesa);
          $material=Material1::all();
          $response = [
              'maleta' => $mesa,
              'existe' => $existe,
               'existe1'=>$existe1,
              'material'=>$material,
              'nombre'=>$nombre
          ];
          return view('sobre', $response);
      }


      public function buscarsobreadmin()
      {
          $codigoMesa = (int)request()->input('CodigoMesa');
          $existe = Mesas::where('CodigoMesa',"=", $codigoMesa)->exists();
          $existe1 =Sobre::where('CodigoMesa',"=", $codigoMesa)->exists();
          $mesa = Mesas::find($codigoMesa);
          $material=Material1::all();
          $response = [
              'maleta' => $mesa,
              'existe' => $existe,
               'existe1'=>$existe1,
              'material'=>$material
          ];
          return view('sobreadmin', $response);
      }

  

 
  

  public function reportem(){
    
    
    $contador1=0;
    $cmesa=Mesas::all();
    $contador=(int)$cmesa->count();

    
   
      $reportem= Maleta::all();

           
     foreach ($cmesa as $dato){

      if($dato->recepcionado=="si"){

          $contador1++;
      }
     
     
    }
    $falta=$contador-$contador1;
    $response = [
      'contador1' => $contador1,
      'falta' => $falta,        
      'reportem'=>$reportem
       
       ];
    
     return view('reportem',$response);








       
        

  }

  public function reportemadmin(){
  

    $contador1=0;
    $cmesa=Mesas::all();
    $contador=(int)$cmesa->count();

    
   
      $reportem= Maleta::all();

           
     foreach ($cmesa as $dato){

      if($dato->recepcionado=="si"){

          $contador1++;
      }
     
     
    }
    $falta=$contador-$contador1;
    $response = [
      'contador1' => $contador1,
      'falta' => $falta,        
      'reportem'=>$reportem
       
       ];
    

         return view('reportemadmin',$response);
     
 

}


  public function reportes(){

    $contador1=0;
    $cmesa=Mesas_sobre::all();
    $contador=(int)$cmesa->count();

    

   
      $reportem= Maleta::all();

     
      
     foreach ($cmesa as $dato){

      
      if($dato->recepcionado=="si"){

          $contador1++;
          
      }
     
     
    }
    $falta=$contador-$contador1;
    $response = [
      'contador1' => $contador1,
      'falta' => $falta,        
      'reportem'=>$reportem
       
       ];
    
     return view('reportes',$response);


  
  }



  public function reportesadmin(){
  
    $contador1=0;
    $cmesa=Mesas_sobre::all();
    $contador=(int)$cmesa->count();

    

   
      $reportem= Maleta::all();

     
      
     foreach ($cmesa as $dato){

      
      if($dato->recepcionado=="si"){

          $contador1++;
          
      }
     
     
    }
    $falta=$contador-$contador1;
    $response = [
      'contador1' => $contador1,
      'falta' => $falta,        
      'reportem'=>$reportem
       
       ];
    
     return view('reportesadmin',$response);


  
  }





  public function agregarm(){
    
    
    return view('agregarm');     

  }

  public function agregars(){
    
    
    return view('agregars');     

  }
 

  public function edicion(){
    
    
    return view('edicion');     

  }

  
  public function ingresousuario(){
    
    
    return view('ingresousuario');     

  }

  
  

  public function buscarm(Request $request ){

    
    $buscam=$request->input('CodigoMesa');
    $existe = Maleta::where('CodigoMesa',"=",$buscam)->exists();
    $mesa = Mesas::find($buscam);
    $material=Maleta::all();
    
    $cont= $material->first();
    $cont1=(int)$cont->id;
    $contador=(int)$material->count();
    $contador=$contador+$cont1;
    
    $id=0;
    $bm=0;
   
    $m=array();
    do {

      $id++;
      $maleta= Maleta::find($id);
      if(!empty($maleta)){
         $bmaleta=$maleta->CodigoMesa ;
          if($bmaleta ==  $buscam){
            
          $m[$id]=$maleta;
                   
           
        
          }
          
       }
       
               
      }while( $id<$contador Or $bm = 0);
      
      $response = [
        'maleta' => $mesa,
         'existe' => $existe,
         'm'=>$m,
         
         ];
        
     return view('maletab',$response);
     
    }  



    public function buscarmadmin(Request $request ){

      $buscam=$request->input('CodigoMesa');
    $existe = Maleta::where('CodigoMesa',"=",$buscam)->exists();

    $mesa = Mesas::find($buscam);
    $material=Maleta::all();
    $cont= $material->first();
    $cont1=(int)$cont->id;
    $contador=(int)$material->count();
    $contador=$contador+$cont1;
    
    $id=0;
    $bm=0;
   
    $m=array();
    do {

      $id++;
      $maleta= Maleta::find($id);
      if(!empty($maleta)){
         $bmaleta=$maleta->CodigoMesa ;
          if($bmaleta ==  $buscam){
            
          $m[$id]=$maleta;
                   
           
        
          }
          
       }
       
               
      }while( $id<$contador Or $bm = 0);
      
      $response = [
        'maleta' => $mesa,
         'existe' => $existe,
        
          'm'=>$m,
         
         ];
     return view('maletabadmin',$response);
     
    }  

    public function buscars(Request $request ){

      
      $buscas=$request->input('CodigoMesa');
      $existe = Sobre::where('CodigoMesa',"=",$buscas)->exists();
      $mesa = Mesas::find($buscas);
      $material= Sobre::all();
      $cont= $material->first();
      $cont1=(int)$cont->id;
      $contador=(int)$material->count();
      $contador=$contador+$cont1;
          
      $bm=0;
      $id=0;
      $s=array();
      
      do {

      
        $id++;
       
          $sobre= Sobre::find($id);
         
         if(!empty($sobre)){

        $bsobre=$sobre->CodigoMesa ; 
        if($bsobre ==  $buscas){
              $s[$id]=$sobre;
             
        }
         }

          
      
        }while( $id<$contador Or $bm = 0);

        

      $response = [
        'maleta' => $mesa,
         'existe' => $existe,
         's'=>$s
                
          
         ];
     return view('sobreb',$response);
    
    
    }  

    public function buscarsadmin( ){
     
      $buscas=(int)request()->input('CodigoMesa');
     
      $existe = Sobre::where('CodigoMesa',"=",$buscas)->exists();
      $mesa = Mesas::find($buscas);
      $material= Sobre::all();
      $cont= $material->first();
     $cont1=(int)$cont->id;
     $contador=(int)$material->count();
      $contador=$contador+$cont1;
      $bm=0;
      $id=0;
      
      $s=array();

      
        do {

      
          
          $id++;
            $sobre= Sobre::find($id);
           
           if(!empty($sobre)){

          $bsobre=$sobre->CodigoMesa ; 
          if($bsobre ==  $buscas){
                $s[]=$sobre;
               
          }
           }

            

          }while( $contador >$id Or $bm = 0);

          

        $response = [
          'maleta' => $mesa,
           'existe' => $existe,
           's'=>$s
                  
            
           ];
       return view('sobrebadmin',$response);
       
      
      
      }  





    public function eliminarm(){

      $materialm=Material ::all();
    
     return view('eliminarm',compact('materialm'));   
  }


    


      public function eliminars(){

        $materials=Material1 ::all();
      
       return view('eliminars',compact('materials'));   
    }


  




    public function nuevom(Request  $request){
    
      $nuevomaterial= new Material;
        $nuevomaterial->material= $request->material;
    
          $nuevomaterial->save();
          
          return back()->with('mensaje','material  agregado a la lista ');
      
    
    }

    public function nuevos(Request  $request){
    
      $nuevomaterial= new Material1;
        $nuevomaterial->material= $request->material;
    
          $nuevomaterial->save();
          
          return back()->with('mensaje','material  agregado a la lista');
      
    
    }
    
    public function eliminam($id){

      $elimimarmaleta= Material::find($id);
      $elimimarmaleta->delete();
      return back()->with('mensaje','material  eliminado');
    
    }
     

    public function eliminas($id){

      $elimimarsobre= Material1::find($id);
      $elimimarsobre->delete();
      return back()->with('mensaje','material  eliminado');
    
    }

    public function guardarm(Request  $request){
    
      
      $data=$request->material;
      foreach ($data as $nuevomaleta=>$valor){
        $nuevomaleta= new Maleta;
        $nuevomaleta->CodigoMesa= $request->CodigoMesa;
        $nuevomaleta->material= $valor;
        $nuevomaleta->observaciones= $request->observaciones;
        
        $nuevomaleta->save();
       
       
      }
       $codigomesa=$request->CodigoMesa;
             $m=1;
       $response = [

        'codigomesa'=> $codigomesa,
        
         'm' => $m,
                                  
         ];
      
       return view('maletai',$response);
    }


    public function guardarmadmin(Request  $request){
    
      
      $data=$request->material;
      foreach ($data as $nuevomaleta=>$valor){
        $nuevomaleta= new Maleta;
        $nuevomaleta->CodigoMesa= $request->CodigoMesa;
        $nuevomaleta->material= $valor;
        $nuevomaleta->observaciones= $request->observaciones;
        
        $nuevomaleta->save();
       
       
       
       
      }
      
       $m=1;
       $response = [
        
         'm' => $m,
                                  
         ];
      
       return view('maletaiadmin',$response);

      
    }





    
    public function guardars(Request  $request){

             
            $data=$request->material;
            foreach ($data as $nuevomaleta=>$valor){
              $nuevomaleta= new Sobre;
              $nuevomaleta->CodigoMesa= $request->CodigoMesa;
              $nuevomaleta->material= $valor;
              $nuevomaleta->observaciones= $request->observaciones;
              
              $nuevomaleta->save();
       
            }
            $codigomesa=$request->CodigoMesa;
                       $s=1;
            $response = [
            'codigomesa'=> $codigomesa,
          
              's' => $s
                                       
              ];
           
            return view('sobrei',$response);
      

    }
  



    public function guardarsadmin(Request  $request){

             
      $data=$request->material;
      foreach ($data as $nuevomaleta=>$valor){
        $nuevomaleta= new Sobre;
        $nuevomaleta->CodigoMesa= $request->CodigoMesa;
        $nuevomaleta->material= $valor;
        $nuevomaleta->observaciones= $request->observaciones;
       
        $nuevomaleta->save();
       
      }
    
   
    $s=1;
    $response = [
     
      's' => $s
                               
      ];
   
    return view('sobreiadmin',$response);
  
}      
             
        
    
  public function buscarusuario(Request $request){


     
      $buscau=$request->input('usuario');
      $existe1 =  (string)Usuario::where('usuario',"=",$buscau)->exists();
      $buscac=$request->input('clave');
      $existe = (string)Usuario::where('clave',"=",$buscac)->exists();
      $datos=Usuario ::all();
      $total=$datos->count();
        
       $id=0;
       $b=1;
       
      do{
        $id++;
        if($existe1==1 And $existe==1){

          
         
         $usuario= Usuario::where('usuario', $buscau)->first();
         $usu= $usuario->nombre;      
      
         view::share('nombre',$usu); 
        

           if($usuario->usuario==$buscau and $usuario->clave==$buscac){
            
           
                  if($usuario->tipo =='maleta'){
                    $b=1;
                    $m=0;
                                           
                    view::share('nombre',$usu); 
                 
                 return view('maletai',compact('m'));
                
               

                  }elseif($usuario->tipo =='sobre'){
                    
                    $b=1;
                    $s=0;
                    view::share('nombre',$usu); 
                   
                    return view('sobrei',compact('s'));
                    

                  }else{
                   
    
                    $b=1;
                    $m=0;
                   
                    return view('administrador',compact('m'));
                    

                   }

                   
              

              }
        
                      
          

        }elseif($existe1!=1){

          return back()->with('mensaje',' El suario  o la clave esta incorrecto');
        }else {
          if($existe!=1){

            return back()->with('mensaje',' El suario  o la clave esta incorrecto');
          }
         
        }
          
                  
               
      }while($id<$total Or $b == 0);                   
     
        
  }
    



  public function agregarusuario(){
    
    
    return view('agregarusuario');     

  }
  

  public function guardarusuario(Request  $request){
    
    $nuevousuario= new User;  
    $nuevousuario->name= $request->name;
    $nuevousuario->email= $request->email;
    $nuevousuario->password= bcrypt("$request->password");
    $nuevousuario->rol= $request->rol;  
         
        $nuevousuario->save();
        
      return back()->with('mensaje',' Usuario agregado');

  }
    
      public function eliminau($id){

        $eliminarusuario= User::find($id);
        $eliminarusuario->delete();
        return back()->with('mensaje','Usuario  eliminado');
      
      }
      public function listausuario(){

        $materialu=User::all();
      
       return view('listausuario',compact('materialu')); 
      }   







public function actualisarm(Request $request){

  $codigoMesa =(int)$request->input('CodigoMesa');  
   $nombre=$request->input('usuario');       
  date_default_timezone_set('America/La_Paz');
  $fechaactual=date("Y-m-d H:i:s");
  


  $maletaupdate=Mesas::findOrFail($codigoMesa);
  $maletaupdate->recepcionado='si';
  $maletaupdate->usuario=$nombre;
  $maletaupdate->fecha=$fechaactual;

  $maletaupdate->save();
 $m=0;


  
  return view('maletai',compact('m')); 
}   



public function actualisarmadmin(Request $request){

     
  $rm=$request->input('recepcionado');

  $mesaupdate=Mesas::findOrFail($rm);
  $mesaupdate->recepcionado='si';
  $mesaupdate->save();
  $m=0;

 
        
 return view('maletaiadmin',compact('m')); 
}   





public function actualisars(Request $request){

  $codigoMesa =(int)$request->input('CodigoMesa');  
   $nombre=$request->input('usuario');       
   date_default_timezone_set('America/La_Paz');
  $fechaactual=date("Y-m-d H:i:s");   
 

  $sobreupdate=Mesas_sobre::findOrFail($codigoMesa);
  $sobreupdate->recepcionado='si';
  $sobreupdate->usuario=$nombre;
  $sobreupdate->fecha=$fechaactual;
  $sobreupdate->save();
  
  $s=0;
 return view('sobrei',compact('s')); 
}   

public function actualisarsadmin(Request $request){

     
  $rs=$request->input('recepcionado');

  $sobreupdate=Mesas_sobre::findOrFail($rs);
  $sobreupdate->recepcionado='si';
  $sobreupdate->save();
  $s=0;
 return view('sobreiadmin',compact('s')); 
}   


public function exportar() 
{
    return Excel::download(new Exportar, 'Maleta.xlsx' );
}

public function exportars() 
{
    return Excel::download(new Exportars, 'Sobre.xlsx' );
}

public function exportarme() 
{
    return Excel::download(new Exportarme, 'Mesas.xlsx' );
}

public function exportarso() 
{
    return Excel::download(new Exportarso, 'Mesas_sobre.xlsx' );
}
/*
public function importarmesam(Request $request) 
{
  $file=$request->file('file');
  
     Excel::import(new Importm, $file);

     return back()->with('mensaje','archivo importado');
   
}*/


  }    
