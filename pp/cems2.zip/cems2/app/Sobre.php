<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Sobre extends Model
{
    public $timestamps = false;
    protected $table = "sobres";
 protected $primaryKey  = "id";
    protected $fillable = [
        
	"CodigoMesa",  
        "material",            
        "observaciones"
      
    ];
}
