<?php

namespace App\Exports;


use App\Sobre;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;

class Exportars implements FromCollection,WithHeadings
{
    public function collection()
    {

        
        return  Sobre::all();
        
    }

    public function headings(): array
    {
	return ['id','CodigoMesa', 'material', 'obcervaciones'];    
    }

   
}
