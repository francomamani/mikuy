<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Material1 extends Model
{
    public $timestamps = false;
    protected $table = "material1s";
    protected $primaryKey  = "id";
    protected $fillable = ["material"];
}
