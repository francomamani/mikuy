@extends('plantillaadmin')


@section('seccion')
<br><br>
@if(session('mensaje'))
 <div class=" alert alert-success">
  {{session('mensaje')}}

  <a href="{{ route('reportemadmin') }}" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

 </div >
 
@endif

<h3 ALIGN="center">REPORTE DE MALETAS RECEPCIONADAS Y NO RECEPCIONADAS<h3>
<br>
<div class="input-group card-footer text-center">
<h4>Maletas recepcionadas:</h4>
<samp><h3>{{$contador1 }}</h3></samp>
</div>
<div class="input-group card-footer text-center">
<h4>maletas que faltan recepcionar:</h4>
<samp><h3>{{$falta }}</h3></samp>

</div>
  <br>
  <div ALIGN="center"  >
  <button  onclick="location.href='{{ route('exportarme') }}'" ><img src="{{ asset('Excel.jpg') }}" />Exportar  maletas recepcionadas y no recepcionadas</button>
  <br><br><br>
  
  </div>
  
  
   
@endsection