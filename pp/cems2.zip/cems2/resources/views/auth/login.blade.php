@extends('plantillaingreso')

@section('seccion')
<div  ALIGN="center">
<h2>Contol  de Entrega de Maletas y Sobres</h2>
</div>
<br><br>
  <div  ALIGN="center">

  <form action="{{route('login')}}" method="POST">
  
  @csrf 
  
    
   <div class=" text-center  col-lg-4">
      <br>
      <input type="name" class="form-control" name="name"  id = "name" value="{{old('name')}}" placeholder="Nombre" >
      {{ $errors->first('name') }}
      <br>
      <input type="password" class="form-control"name="password" id= "password" placeholder="Password" >
      {{ $errors->first('password') }}
        <br>
        <button type = "submit"class="btn btn-secondary" type="button">INGRESAR</button>
      
    </div>
  </div>

   
  </form>
  
 

  <br><br><br><br><br>
  


  
@endsection
