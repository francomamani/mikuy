@extends('plantillaadmin')

@section('seccion')

@if($existe1 === false)

    @if($existe === true)
        <br><br>
        <div class="card">
            <div class="card-header">
                <h3>SOBRES</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <tbody>
                        <tr>
                            <td>Codigo de mesa:</td>
                            <td>{{$maleta->CodigoMesa}}</td>
                        </tr>
                        <tr>
                            <td>nombre departamento:</td>
                            <td>{{$maleta->departamento}}</td>
                        </tr>
                        <tr>
                            <td>nombre provincia:</td>
                            <td>{{$maleta->provincia}}</td>
                        </tr>
                        <tr>
                            <td>nombre municipio:</td>
                            <td>{{$maleta->municipio}}</td>
                        </tr>
                        <tr>
                            <td>asiento electoral:</td>
                            <td>{{$maleta->asiento}}</td>
                        </tr>
                        <tr>
                            <td>nombre distrito:</td>
                            <td>{{$maleta->distrito}}</td>
                        </tr>
                        <tr>
                            <td>nombre zona:</td>
                            <td>{{$maleta->zona}}</td>
                        </tr>
                        <tr>
                            <td>nombre recinto</td>
                            <td>{{$maleta->nombre_recinto}}</td>
                        </tr>
                        <tr>
                            <td>circunscripcion:</td>
                            <td>{{$maleta->circunscripcion}}</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>

    
    <br>

        <style>
            .outlinenone {
            outline: none;
             background-color: #d7d7c1;
             border: 0;
            }
        </style>
       
       <div class="table-responsive">
                  <table class="table ">
                     <thead class="thead-dark">
   <tr>
     <!--<th scope="col">#</th>-->
     <th scope="col">Codigo de mesa:{{$maleta->CodigoMesa}}</th>
     <th scope="col">Material</th>
     <th scope="col"></th>
     <th scope="col"></th>
   </tr>
 </thead>
 <tbody>
 
 <form action="{{route('guardarsadmin')}}" method="POST">
 @csrf 
 <input type="hidden" name= recepcionado value="si">
 <input type="hidden" name= nombre value=" {{$nombre}}">
 @foreach($material as $item)
   <tr>
     
     
       
                        <td><input type="hidden"class="form-control"name="CodigoMesa" value="{{$maleta->CodigoMesa}}"readonly="readonly"></td>
                        <td><label for="{{$item->material}}">{{$item->material}}</label><td>
                        <td><input type="checkbox" name="material[]" id="amaterial[]" value="{{$item->material}}"></td>
                                                                 
                    
   </tr>
   @endforeach()  
      
   
 </tbody>
</table>


</div>
<br>
<h6>OBSERVACIONES:<H6>
<input type="text"class="form-control"name="descripcion" value=" " placeholder="Descripcion">
<br>
<button class="btn btn-dark" type = "submit" >GUARDAR</button>

</form>
  
@else
    <br><br><br>
    <div class="card-footer text-center">
        <div class="alert alert-info">EL SOBRE  CON EL CODIGO NO EXISTE</div>
        <button class="btn btn-secondary" type="button" action="{{route('sobrei')}}">GUARDAR</button>
    </div>                    
    @endif
    @else
    <br><br><br>
    <div class="card-footer text-center">
        <div class="alert alert-info">EL SOBRE YA FUE ENTREGADO</div>
                        <a href="/sobreiadmin" class="btn btn-primary">aceptar</a>
    </div>                    
    @endif
  
  
  
  @endsection