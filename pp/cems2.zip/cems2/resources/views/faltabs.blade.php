@extends('plantillaadmin')

@section('seccion')
<br>
  <h5>ESTE SOBRE"A" UN NO FUE ENTREGADO<h5>
        <br><br>
        <div class="card">
            <div class="card-header">
                <h3>SOBRE</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <tbody>
                        <tr>
                            <td>Codigo de mesa:</td>
                            <td>{{$maleta->CodigoMesa}}</td>
                        </tr>
                        <tr>
                            <td>nombre departamento:</td>
                            <td>{{$maleta->departamento}}</td>
                        </tr>
                        <tr>
                            <td>nombre provincia:</td>
                            <td>{{$maleta->provincia}}</td>
                        </tr>
                        <tr>
                            <td>nombre municipio:</td>
                            <td>{{$maleta->municipio}}</td>
                        </tr>
                        <tr>
                            <td>asiento electoral:</td>
                            <td>{{$maleta->asiento}}</td>
                        </tr>
                        <tr>
                            <td>nombre distrito:</td>
                            <td>{{$maleta->distrito}}</td>
                        </tr>
                        <tr>
                            <td>nombre zona:</td>
                            <td>{{$maleta->zona}}</td>
                        </tr>
                        <tr>
                            <td>nombre recinto</td>
                            <td>{{$maleta->nombre_recinto}}</td>
                        </tr>
                        <tr>
                            <td>circunscripcion:</td>
                            <td>{{$maleta->circunscripcion}}</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
           
        </div>

 @endsection   
