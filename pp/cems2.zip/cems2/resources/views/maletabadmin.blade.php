@extends('plantillaadmin')

@section('seccion')
    @if($existe === true)
        <br><br>
        <div class="card">
            <div class="card-header">
                <h3>MALETAS</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <tbody>
                        <tr>
                            <td>Codigo de mesa:</td>
                            <td>{{$maleta->CodigoMesa}}</td>
                        </tr>
                        <tr>
                            <td>nombre departamento:</td>
                            <td>{{$maleta->departamento}}</td>
                        </tr>
                        <tr>
                            <td>nombre provincia:</td>
                            <td>{{$maleta->provincia}}</td>
                        </tr>
                        <tr>
                            <td>nombre municipio:</td>
                            <td>{{$maleta->municipio}}</td>
                        </tr>
                        <tr>
                            <td>asiento electoral:</td>
                            <td>{{$maleta->asiento}}</td>
                        </tr>
                        <tr>
                            <td>nombre distrito:</td>
                            <td>{{$maleta->distrito}}</td>
                        </tr>
                        <tr>
                            <td>nombre zona:</td>
                            <td>{{$maleta->zona}}</td>
                        </tr>
                        <tr>
                            <td>nombre recinto</td>
                            <td>{{$maleta->nombre_recinto}}</td>
                        </tr>
                        <tr>
                            <td>circunscripcion:</td>
                            <td>{{$maleta->circunscripcion}}</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
           
        </div>

    

    <br>
        
                           
 
         <div class="table-responsive">
                   <table class="table ">
                      <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">lista de materiales de la maleta: {{$maleta->CodigoMesa}}</th>
          <th scope="col"></th>
    </tr>
  </thead>
  <tbody>
  @foreach($m as $item)
    <tr>
      <th scope="row">{{$item->id}}</th>
         <td>{{$item->material}}</td>
    </tr>
    @endforeach()  
  </tbody>
</table>
<h6>OBSERVACIONES:</h6>
<h5>{{$item->descripcion}}</h5>

</div>

           @else
    <br><br><br>
    <div class="card-footer text-center">
        <div class="alert alert-info">LA MALETA A UN NO FUE REGISTRADA</div>
                        <a href="/reportem" class="btn btn-primary">aceptar</a>
    </div>                    
    @endif

@endsection