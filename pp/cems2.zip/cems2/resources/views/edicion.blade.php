@extends('plantilla1')

@section('seccion')
<a href="{{ route('eliminarm') }}" class="btn btn-primary ">eliminar maleta</a>
<a href="{{ route('eliminars') }}" class="btn btn-primary ">eliminar sobre</a>
@endsection