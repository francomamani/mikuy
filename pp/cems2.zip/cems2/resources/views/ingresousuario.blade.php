@extends('plantillaingreso')

@section('seccion')
<div  ALIGN="center">
<h2>Contol  de Entrega de Maletas y Sobres</h2>
</div>
<br><br>
  <div  ALIGN="center">

  <form action="{{route('buscarusuario')}}" method="POST">
  
  @csrf 
  
  
  
   <div class=" text-center  col-lg-4">
      <br>
      <td><input type="int" class="form-control"name="usuario" placeholder="usuario" ></td>
      <br>
      <td><input type="password" class="form-control"name="clave" placeholder="clave" ></td>
        <br>
        <button type = "submit"class="btn btn-secondary" type="button">INGRESAR</button>
      
    </div>
  </div>

   
  </form>
  
  @if(session('mensaje'))
 <div class=" alert alert-success">
  {{session('mensaje')}}

  <a href="{{ route('ingresousuario') }}" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

 </div>
@endif
  <br><br><br><br><br>
  


  
@endsection
