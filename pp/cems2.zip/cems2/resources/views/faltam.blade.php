@extends('plantillaadmin')


@section('seccion')
<br><br>
@if(session('mensaje'))
 <div class=" alert alert-success">
  {{session('mensaje')}}

  <a href="{{ route('faltam') }}" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

 </div >
@endif

<h3 ALIGN="center">REPORTE DE MALETAS QUE FALTAN RECEPCIONAR<h3>
<br>
<h6>Maletas recepcionadas:</h6><h4>{{$contador1 }}</h4>

<h6>maletas que faltan recepcionar:</h6><h4>{{$falta }}</h4>

<div ALIGN="right">

  <form action="{{route('buscarfm')}}" method="POST">
  
  @csrf 
  <div class="col-lg-6",>
   <div class="input-group card-footer text-center">
      <input type="int" class="form-control"name="CodigoMesa" placeholder="Codigo de Mesa" >
      <span class="input-group-btn">
        <button type = "submit"class="btn btn-warning" type="button">BUSCAR</button>
      </span>
    </div>
  </div>
</div>
    
  </form>
  </div>
  @csrf 
    <br>
  <h4 ALIGN="center">LISTA DE MALETAS QUE FALTAN RECEPCIONAR</h4>

 
        
             
                   <div class="table-responsive">
                   <table class="table ">
                      <thead class="thead-dark">
    <tr>
     
      <th scope="col">Codigo de mesa</th>
      <th scope="col">Recinto</th>
      <th scope="col">Circunscripcion</th>
    </tr>
  </thead>
  <tbody>
  @foreach($f as $item)
    <tr>
      <td>{{$item->CodigoMesa}}</td>
      <th scope="row">{{$item->nombre_recinto}}</th>
      <td>{{$item->circunscripcion}}</td>
     
   
    </tr>
    @endforeach()  
  </tbody>
</table>
</div>
@endsection