@extends('plantillaadmin')

@section('seccion')
<br><br><br>


@if($m == 0)

<h1 ALIGN="center">RECEPCION  DE LA MALETA</h1>
<div>
<br><br>
  <div  ALIGN="center">
  <form action="{{route('buscarMesaadmin')}}" method="POST">
  
  @csrf 
  <div class="col-lg-6",>
   <div class="input-group card-footer text-center">
      <input type="int" class="form-control"name="CodigoMesa" placeholder="Codigo de Mesa" >
      <span class="input-group-btn">
        <button type = "submit"class="btn btn-warning" type="button">BUSCAR</button>
      </span>
    </div>
  </div>
</div>
    
</form>  
  </div>


  @else
    <br><br><br>
    <div class="card-footer text-center">
                    <div class="alert alert-info">LA MALETA FUE REGISTRADA EXITOSAMENTE</div>
                    <a href="/maletaiadmin" class="btn btn-primary">aceptar</a>
                       
     </form>                   
    </div>                    

       @endif  
<br><br><br>
  
@endsection