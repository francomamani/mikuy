<?php

use Illuminate\Database\Seeder;
use App\User;
class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    { User::create(["name" => "usuario",
        "email" => "usuario@gmail.com",
        "password" => bcrypt("usuario"),"rol"=> "administrador"]);
        // $this->call(UsersTableSeeder::class);
    }
}
