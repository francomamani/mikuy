<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateMesasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('mesas', function (Blueprint $table) {
            
  $table->integer('CodigoMesa')->unsigned();
  $table->primary('CodigoMesa');
  $table->string('departamento');
  $table->string('provincia');
  $table->string('municipio');
  $table->string('asiento');
  $table->string('distrito');
  $table->string('zona');
  $table->string('nombre_recinto');
  $table->integer('circunscripcion');
  $table->string('nombres');
  $table->string('primer_apellido');
  $table->string('segundo_apellido');
  $table->string('numero_documento');
  $table->integer('numero_telefono');
  $table->string('recepcionado')->nullable();
  $table->string('usuario')->nullable();
  $table->datetime('fecha')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('mesas');
    }
}
