<?php $__env->startSection('seccion'); ?>
<?php if(session('mensaje')): ?>
       <div class="alert alert-success text-center">
        <?php echo e(session('mensaje')); ?>

       
        <a href="<?php echo e(route('eliminars')); ?>" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

       </div>

       <?php endif; ?>
<div class="card-footer  input-group">
<h1>ingresa el nuevo material para el sobre "A"</h1>
</div>
<div>
  <form action="<?php echo e(route('nuevos')); ?>" method="POST">
  
  <?php echo csrf_field(); ?> 
  <div class="col-lg-6",>
   <div class="input-group card-footer text-center">
      <input type="int" class="form-control"name="material" placeholder="Nombre del nuevo material " >
      <span class="input-group-btn">
        <button type = "submit"class="btn btn-primary" type="button">AGREGAR</button>
      </span>
    </div>
  </div>
</div>
    
  </form>
  </div>
   
   <?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\cems2\resources\views/agregars.blade.php ENDPATH**/ ?>