<?php $__env->startSection('seccion'); ?>

  <?php $__currentLoopData = $equipo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $personal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

   <a href="<?php echo e(route('nosotros',$personal)); ?>"class="h4 text-danger"><?php echo e($personal); ?></a><br>
 
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     
    
    <?php if(!empty($nombre)): ?>
  
        <?php switch($nombre):

           case ($nombre=='Ignacio'): ?>
              <h2>el nombre es <?php echo e($nombre); ?>:</h2>

            <?php break; ?>


            <?php case ($nombre=='Juanito'): ?>
              <h2>el nombre es <?php echo e($nombre); ?>:</h2>

            <?php break; ?>

            <?php case ($nombre=='Pedrito'): ?>
              <h2>el nombre es <?php echo e($nombre); ?>:</h2>

            <?php break; ?>
        <?php endswitch; ?>
     
     <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\cems2\resources\views/nosotros.blade.php ENDPATH**/ ?>