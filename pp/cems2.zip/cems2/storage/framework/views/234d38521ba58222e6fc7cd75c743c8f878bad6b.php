<?php $__env->startSection('seccion'); ?>
<div  ALIGN="center">
<h2>Contol  de Entrega de Maletas y Sobres</h2>
</div>
<br><br>
  <div  ALIGN="center">

  <form action="<?php echo e(route('buscarusuario')); ?>" method="POST">
  
  <?php echo csrf_field(); ?> 
  
  
  
   <div class=" text-center  col-lg-4">
      <br>
      <td><input type="int" class="form-control"name="usuario" placeholder="usuario" ></td>
      <br>
      <td><input type="password" class="form-control"name="clave" placeholder="clave" ></td>
        <br>
        <button type = "submit"class="btn btn-secondary" type="button">INGRESAR</button>
      
    </div>
  </div>

   
  </form>
  
  <?php if(session('mensaje')): ?>
 <div class=" alert alert-success">
  <?php echo e(session('mensaje')); ?>


  <a href="<?php echo e(route('ingresousuario')); ?>" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

 </div>
<?php endif; ?>
  <br><br><br><br><br>
  


  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillaingreso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\cems2\resources\views/ingresousuario.blade.php ENDPATH**/ ?>