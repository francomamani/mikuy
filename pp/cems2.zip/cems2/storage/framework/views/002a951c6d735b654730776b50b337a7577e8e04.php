<?php $__env->startSection('seccion'); ?>
<br><br>
<?php if(session('mensaje')): ?>
 <div class=" alert alert-success">
  <?php echo e(session('mensaje')); ?>


  <a href="<?php echo e(route('faltam')); ?>" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

 </div >
<?php endif; ?>

<h3 ALIGN="center">REPORTE DE SOBRES "A" QUE FALTAN RECEPCIONAR<h3>
<br>
<h6>Maletas recepcionadas:</h6><h4><?php echo e($contador1); ?></h4>

<h6>maletas que faltan recepcionar:</h6><h4><?php echo e($falta); ?></h4>

<div ALIGN="right">

  <form action="<?php echo e(route('buscarfs')); ?>" method="POST">
  
  <?php echo csrf_field(); ?> 
  <div class="col-lg-6",>
   <div class="input-group card-footer text-center">
      <input type="int" class="form-control"name="CodigoMesa" placeholder="Codigo de Mesa" >
      <span class="input-group-btn">
        <button type = "submit"class="btn btn-success" type="button">BUSCAR</button>
      </span>
    </div>
  </div>
</div>
    
  </form>
  </div>
  <?php echo csrf_field(); ?> 
    <br>
  <h4 ALIGN="center">LISTA DE SOBRES "A" QUE FALTAN RECEPCIONAR</h4>

 
        
             
                   <div class="table-responsive">
                   <table class="table ">
                      <thead class="thead-dark">
    <tr>
     
      <th scope="col">Codigo de mesa</th>
      <th scope="col">Recinto</th>
      <th scope="col">Circunscripcion</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $f; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <td><?php echo e($item->CodigoMesa); ?></td>
      <th scope="row"><?php echo e($item->nombre_recinto); ?></th>
      <td><?php echo e($item->circunscripcion); ?></td>
     
   
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
  </tbody>
</table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillaadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\cems2\resources\views/faltas.blade.php ENDPATH**/ ?>