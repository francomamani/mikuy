<?php $__env->startSection('seccion'); ?>
    <?php if($existe === true): ?>
        <br><br>
        <div class="card">
            <div class="card-header">
                <h3>MALETAS</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <tbody>
                        <tr>
                            <td>Codigo de mesa:</td>
                            <td><?php echo e($maleta->CodigoMesa); ?></td>
                        </tr>
                        <tr>
                            <td>nombre departamento:</td>
                            <td><?php echo e($maleta->departamento); ?></td>
                        </tr>
                        <tr>
                            <td>nombre provincia:</td>
                            <td><?php echo e($maleta->provincia); ?></td>
                        </tr>
                        <tr>
                            <td>nombre municipio:</td>
                            <td><?php echo e($maleta->municipio); ?></td>
                        </tr>
                        <tr>
                            <td>asiento electoral:</td>
                            <td><?php echo e($maleta->asiento); ?></td>
                        </tr>
                        <tr>
                            <td>nombre distrito:</td>
                            <td><?php echo e($maleta->distrito); ?></td>
                        </tr>
                        <tr>
                            <td>nombre zona:</td>
                            <td><?php echo e($maleta->zona); ?></td>
                        </tr>
                        <tr>
                            <td>nombre recinto</td>
                            <td><?php echo e($maleta->nombre_recinto); ?></td>
                        </tr>
                        <tr>
                            <td>circunscripcion:</td>
                            <td><?php echo e($maleta->circunscripcion); ?></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
           
        </div>

    

    <br>
        <tr>
      <td><h3>LISTA DE MATERIALES DE LA MALETA : <?php echo e($maleta->CodigoMesa); ?></h3></td>
         </tr>
                           
 
         <div class="table-responsive">
                   <table class="table ">
                      <thead class="thead-dark">
    <tr>
      <th scope="col">#</th>
      <th scope="col">Codigo de mesa</th>
      <th scope="col">Material</th>
      <th scope="col">Descripcion</th>
    </tr>
  </thead>
  <tbody>
  <?php $__currentLoopData = $m; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
      <th scope="row"><?php echo e($item->id); ?></th>
      <td><?php echo e($item->CodigoMesa); ?></td>
      <td><?php echo e($item->material); ?></td>
      <td><?php echo e($item->descripcion); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
  </tbody>
</table>
</div>

           <?php else: ?>
    <br><br><br>
    <div class="card-footer text-center">
        <div class="alert alert-info">LA MALETA A UN NO FUE REGISTRADA</div>
                        <a href="/reportem" class="btn btn-primary">aceptar</a>
    </div>                    
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillaadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\cems2\resources\views/maletabadmin.blade.php ENDPATH**/ ?>