<?php $__env->startSection('seccion'); ?>
<a href="<?php echo e(route('eliminarm')); ?>" class="btn btn-primary ">eliminar maleta</a>
<a href="<?php echo e(route('eliminars')); ?>" class="btn btn-primary ">eliminar sobre</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla1', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\cems2\resources\views/edicion.blade.php ENDPATH**/ ?>