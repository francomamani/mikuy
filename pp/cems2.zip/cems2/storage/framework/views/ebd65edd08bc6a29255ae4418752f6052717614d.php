<?php $__env->startSection('seccion'); ?>

<?php if($existe1 === false): ?>

    <?php if($existe === true): ?>
        <br><br>
        <div class="card">
            <div class="card-header">
                <h3>SOBRES</h3>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped">
                        <tbody>
                        <tr>
                            <td>Codigo de mesa:</td>
                            <td><?php echo e($maleta->CodigoMesa); ?></td>
                        </tr>
                        <tr>
                            <td>nombre departamento:</td>
                            <td><?php echo e($maleta->departamento); ?></td>
                        </tr>
                        <tr>
                            <td>nombre provincia:</td>
                            <td><?php echo e($maleta->provincia); ?></td>
                        </tr>
                        <tr>
                            <td>nombre municipio:</td>
                            <td><?php echo e($maleta->municipio); ?></td>
                        </tr>
                        <tr>
                            <td>asiento electoral:</td>
                            <td><?php echo e($maleta->asiento); ?></td>
                        </tr>
                        <tr>
                            <td>nombre distrito:</td>
                            <td><?php echo e($maleta->distrito); ?></td>
                        </tr>
                        <tr>
                            <td>nombre zona:</td>
                            <td><?php echo e($maleta->zona); ?></td>
                        </tr>
                        <tr>
                            <td>nombre recinto</td>
                            <td><?php echo e($maleta->nombre_recinto); ?></td>
                        </tr>
                        <tr>
                            <td>circunscripcion:</td>
                            <td><?php echo e($maleta->circunscripcion); ?></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            
        </div>

    
    <br>

        <style>
            .outlinenone {
            outline: none;
             background-color: #d7d7c1;
             border: 0;
            }
        </style>
       
       <div class="table-responsive">
                  <table class="table ">
                     <thead class="thead-dark">
   <tr>
     <!--<th scope="col">#</th>-->
     <th scope="col">Codigo de mesa: <?php echo e($maleta->CodigoMesa); ?></th>
     <th scope="col">Material</th>
     <th scope="col"></th>
     <th scope="col"></th>
   </tr>
 </thead>
 <tbody>
 
 
 <?php $__currentLoopData = $material; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
     
   <form action="<?php echo e(route('guardars')); ?>" method="POST">
 <?php echo csrf_field(); ?> 
 
        
                       
                        <td><input type="hidden"class="form-control"name="CodigoMesa" value="<?php echo e($maleta->CodigoMesa); ?>"readonly="readonly"></td>
                        <td><label for="<?php echo e($item->material); ?>"><?php echo e($item->material); ?></label><td>
                        <td><input type="checkbox" name="material[]" id="amaterial[]" value="<?php echo e($item->material); ?>"></td>
                                                                 
                    
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
      
   
 </tbody>
</table>


</div>
<br>
<h6>OBSERVACIONES:<H6>
<input type="text"class="form-control"name="descripcion" value=" " placeholder="Descripcion">
<br>
<button class="btn btn-dark" type = "submit" >GUARDAR</button>

</form>
  
<?php else: ?>
    <br><br><br>
    <div class="card-footer text-center">
        <div class="alert alert-info">EL SOBRE  CON EL CODIGO NO EXISTE</div>
        <button class="btn btn-secondary" type="button" action="<?php echo e(route('sobrei')); ?>">GUARDAR</button>
    </div>                    
    <?php endif; ?>
    <?php else: ?>
    <br><br><br>
    <div class="card-footer text-center">
        <div class="alert alert-info">EL SOBRE YA FUE RECEPCIONADO</div>
                        <a href="/sobrei" class="btn btn-primary">aceptar</a>
    </div>                    
    <?php endif; ?>
  
  
  
  <?php $__env->stopSection(); ?>
  
<?php echo $__env->make('plantillasobre', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\cems2\resources\views/sobre.blade.php ENDPATH**/ ?>