<?php $__env->startSection('seccion'); ?>
<br><br>
<?php if(session('mensaje')): ?>
 <div class=" alert alert-success">
  <?php echo e(session('mensaje')); ?>


  <a href="<?php echo e(route('reportem')); ?>" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

 </div >
 
<?php endif; ?>

<h6>USUARIO: <?php echo e($nombre); ?></h6>

  
<br>
<h3 ALIGN="center">REPORTE DE MALETAS RECEPCIONADAS Y NO RECEPCIONADAS<h3>
<br>
<div class="input-group card-footer text-center">
<h4>Maletas recepcionadas:</h4>
<samp><h3><?php echo e($contador1); ?></h3></samp>
</div>
<div class="input-group card-footer text-center">
<h4>maletas que faltan recepcionar:</h4>
<samp><h3><?php echo e($falta); ?></h3></samp>

</div>
  <br>
  <div ALIGN="center"  >
  <button  onclick="location.href='<?php echo e(route('exportarme')); ?>'" ><img src="<?php echo e(asset('Excel.jpg')); ?>" />Exportar  maletas registradas y no regitradas</button>
  <br><br><br>
  
  </div>
  
  



   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillamaleta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\cems2\resources\views/reportem.blade.php ENDPATH**/ ?>