<?php $__env->startSection('seccion'); ?>
<br><br>


<a href="<?php echo e(route('reportes')); ?>" class="btn btn-primary ">Reporte de sobres</a>

      <a href="<?php echo e(route('reportem')); ?>" class="btn btn-primary ">Reporte  de maleta</a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\cems2\resources\views/reporte.blade.php ENDPATH**/ ?>