<?php $__env->startSection('seccion'); ?>


<img class=" img-fluid btn-block" src="fondo4.jpg" >
<br>
<div ALING="center">BIENVENIDO :</div>
<br>

<h5> Al CONTROL DE ENTREGA DE  MALETAS Y SOBRES</h5>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillaadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\cems2\resources\views/administrador.blade.php ENDPATH**/ ?>