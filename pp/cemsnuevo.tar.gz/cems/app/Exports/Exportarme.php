<?php

namespace App\Exports;


use App\Mesas;
use Illuminate\Contracts\View\View;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;


class Exportarme implements FromCollection,WithHeadings
{
    public function collection()
    {

        
        return  Mesas::all();
        
    }

    public function headings(): array
    {
    return ['CodigoMesa','departamento', 'provincia', 'municipio','asiento','distrito','zona','nombre_recinto',
           'circunscripcion','nombres','primer_apellido','segundo_apellido',
           'numero_documento','numero_telefono','recepcionado','usuario','fecha'];    
    

 
    }

}
