<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;
class LoginController extends Controller
{

    public function __construct(){


         $this->middleware('guest',['only'=>'showLoginForm']);
       
     

    }

    public function showLoginForm(){


        return view ('auth.login');

    }

    

    public function login(){


        $credentials = request()->only('name', 'password');
 
                
         
        if (Auth::attempt($credentials)) {
          
          
            if(Auth::user()->rol=== 'administrador'){

                return redirect()->route('administrador');

            }

            if(Auth::user()->rol=== 'maleta'){

                return redirect()->route('maletai');

            }

            if(Auth::user()->rol=== 'sobre'){

                return redirect()->route('sobrei');

            }

           
           
           
        }
        
        return back()
             ->withInput(request(['$this->username']));
        
              
    }


    public function username(){


        return  'name';

    }


   public function logoaut(){


      auth()->logout();

     return redirect('login');

   }

}
