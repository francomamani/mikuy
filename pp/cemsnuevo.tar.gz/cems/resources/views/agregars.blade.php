@extends('plantilla')

@section('seccion')
@if(session('mensaje'))
       <div class="alert alert-success text-center">
        {{session('mensaje')}}
       
        <a href="{{ route('eliminars') }}" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

       </div>

       @endif
<div class="card-footer  input-group">
<h1>ingresa el nuevo material para el sobre "A"</h1>
</div>
<div>
  <form action="{{route('nuevos')}}" method="POST">
  
  @csrf 
  <div class="col-lg-6",>
   <div class="input-group card-footer text-center">
      <input type="int" class="form-control"name="material" placeholder="Nombre del nuevo material " >
      <span class="input-group-btn">
        <button type = "submit"class="btn btn-primary" type="button">AGREGAR</button>
      </span>
    </div>
  </div>
</div>
    
  </form>
  </div>
   
   @endsection