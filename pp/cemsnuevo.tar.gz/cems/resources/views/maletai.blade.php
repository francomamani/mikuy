@extends('plantillamaleta')

@section('seccion')
<br><br><br>


@if($m == 0)


<h1 ALIGN="center">RECEPCION  DE LA MALETA</h1>

<br><br>
  <div  ALIGN="center">
  <form action="{{route('buscarMesa')}}" method="POST">
  
  @csrf 
  <div class="col-lg-6",>
   <div class="input-group card-footer text-center">
        <input type="int" class="form-control"name="CodigoMesa" placeholder="Codigo de Mesa" >
      <span class="input-group-btn">
        <button type = "submit"class="btn btn-warning" type="button">BUSCAR</button>
      </span>
    </div>
  </div>
</div>
    
</form>  
  </div>


  @else
    <br><br><br>
    <div class="card-footer text-center">
    <form action="{{route('actualisarm')}}" method="POST">
    @csrf 
    @method('PUT')
    
    <input type="hidden" name="usuario" value="{{Auth::user()->name}}">
    <input type="hidden" name="CodigoMesa" value="{{$codigomesa}}">

                <div class="alert alert-info">EL SOBRE "A" FUE REGISTRADO EXITOSAMENTE</div>
                <button type = "submit"class="btn btn-primary" type="button">ACEPTAR</button>
                       
     </form>                   
    </div>                    

       @endif  
<br><br><br>
  
@endsection