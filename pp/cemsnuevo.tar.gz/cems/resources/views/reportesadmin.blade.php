@extends('plantillaadmin')

@section('seccion')
<br><br>
@if(session('mensaje'))
 <div class=" alert alert-success">
  {{session('mensaje')}}

  <a href="{{ route('reportesadmin') }}" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

 </div >
@endif


<h3 ALIGN="center">REPORTE DE SOBRES "A" RECEPCIONADOS Y NO RECEPCIONADOS<h3>
<br>
<div class="input-group card-footer text-center">
<h4>Sobres "A" recepcionados:</h4>
<samp><h3>{{$contador1 }}</h3></samp>
</div>
<div class="input-group card-footer text-center">
<h4>Sobres "A" que faltan recepcionar:</h4>
<samp><h3>{{$falta }}</h3></samp>


</div>
  <br>
  <div ALIGN="center"  >
  <button  onclick="location.href='{{ route('exportarso') }}'" ><img src="{{ asset('Excel.jpg') }}" />Exportar  sobres "A" recepcionados y no recepcionados</button>
  <br><br><br>
  
  </div> 


   
@endsection