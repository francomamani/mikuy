@extends('plantillaadmin')

@section('seccion')


<img class=" img-fluid btn-block" src="{{asset('img/fondo4.jpg')}}" >
<br>
<div ALING="center">BIENVENIDO :</div>
<br>

<h5> Al CONTROL DE ENTREGA DE  MALETAS Y SOBRES</h5>



@endsection
