@extends('plantillaadmin')

@section('seccion')

@if(session('mensaje'))
 <div class=" alert alert-success">
  {{session('mensaje')}}

  <a href="{{ route('agregarusuario') }}" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

 </div >
@endif

<br><br>
  <div   ALIGN="center",>
    <form action="{{route('guardarusuario')}}" method="POST">
  
    @csrf 
      <div class="col-lg-4"  ALIGN="center",>
        <div class="card-footer text-center">

          <br>
            <td><input type="int" class="form-control"name="name" placeholder="nombre" ></td>
                <br>
                <td><input type="int" class="form-control"name="email" placeholder="email" ></td>
                <br>
                <td><input type="int" class="form-control"name="password" placeholder="clave" ></td>
                <br>
            <h5>Tipo de usuario:</h5>
                      <select id="opciones" name="rol" class="form-control form-control-lg1">
                        <option value="administrador">Administrador</option>
                        <option value="maleta">Maleta</option>
                        <option value="sobre">Sobre</option>                       
                       </select>
        <br><br>
        <button type = "submit"class="btn btn-primary" type="button">GUARDAR</button>
      
    </div>
  </div>
</div>
    
  </form>
  </div>
<br><br>


  
@endsection