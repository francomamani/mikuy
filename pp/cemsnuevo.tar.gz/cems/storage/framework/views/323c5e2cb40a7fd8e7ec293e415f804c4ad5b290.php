<!doctype html>
<html lang="en">
  <head >
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>CEMS</title>

    <img class="img-fluid" src="<?php echo e(asset('img/logo_oep2.png')); ?>" >

  </head>
  <body style="background-color:#d7d7c1;" >
  
  
        
      
        <div class="btn-group  btn-block" role="group" aria-label="Basic example">

        
        <button type="button" class="btn btn-danger" onclick="location.href='<?php echo e(route('administrador')); ?>'">Inicio</button>

        <div class="dropdown">
          <button class="btn btn-warning dropdown-toggle " type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Maletas
        </button>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <!--<a class="dropdown-item" href="maletaiadmin">Entrega maleta</a>-->
        <a class="dropdown-item" href="reportemadmin">Reporte maletas</a>
        <a class="dropdown-item" href="reportemcodigoadmin">Reporte de maletas por codigo </a>
        </div>
        </div>
        

        <div class="dropdown">
          <button class="btn btn-success dropdown-toggle " type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Sobres
        </button>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <!--<a class="dropdown-item" href="sobreiadmin">Entrega sobre</a>-->
        <a class="dropdown-item" href="reportesadmin">Reporte sobre "A"</a>
        <a class="dropdown-item" href="reportescodigoadmin">Reporte sobre"A" por codigo</a>
      
        </div>
        </div>


        <div class="dropdown">
          <button class="btn btn-info dropdown-toggle " type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
         Usuarios
        </button>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
        <a class="dropdown-item" href="agregarusuario">Nuevo usuario</a>
        <a class="dropdown-item" href="listausuario">Lista de usuarios</a>
        </div>
        </div>

        
        <button type="button" class="btn btn-secondary"  onclick="location.href='<?php echo e(route('eliminarm')); ?>'" >Material de la maleta</button>
           
        <button type="button" class="btn btn-dark" onclick="location.href='<?php echo e(route('eliminars')); ?>'">Material del sobre</button>

            
      
        <div class="dropdown">
          <button class="btn btn-secondary dropdown-toggle " type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Usuario: <?php echo e(Auth::user()->name); ?>

        </button>
        <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
       <form  action="<?php echo e(route('logoaut')); ?>" method="POST">
          <?php echo csrf_field(); ?> 
        <button class="dropdown-item" type="submit">Cerrar Sesion</button>
        </form>
        </div>
        </div>
      
      
        </div>

        
            
        
        

   <div class="container">
   <?php echo $__env->yieldContent('seccion'); ?>
 </div>
<!-- Footer -->
<footer style="background-color:#00cc44;"class="page-footer font-small ">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2020 Tribunal Electoral Departamental De Oruro:
    <a href="https://www.oep.org.bo/"> www.oep.org.bo</a>
  </div>
  <div  ALIGN="right">
  version: 1.1   Jose Luis Flores Rivera
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->
   <div></div>

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
  
  
  </body>
  
</html>

<?php /**PATH D:\proyectos\cems2\resources\views/plantillaadmin.blade.php ENDPATH**/ ?>