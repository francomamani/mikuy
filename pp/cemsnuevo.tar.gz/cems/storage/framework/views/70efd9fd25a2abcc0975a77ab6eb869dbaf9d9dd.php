

<?php $__env->startSection('seccion'); ?>


<img class=" img-fluid btn-block" src="<?php echo e(asset('img/fondo4.jpg')); ?>" >
<br>
<div ALING="center">BIENVENIDO :</div>
<br>

<h5> Al CONTROL DE ENTREGA DE  MALETAS Y SOBRES</h5>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillaadmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/franco/Documents/pepe/production/new/cems/resources/views/administrador.blade.php ENDPATH**/ ?>