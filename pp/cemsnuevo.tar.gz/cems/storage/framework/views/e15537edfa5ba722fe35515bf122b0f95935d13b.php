

<?php $__env->startSection('seccion'); ?>
<div  ALIGN="center">
<h2>Contol  de Entrega de Maletas y Sobres</h2>
</div>
<br><br>
  <div  ALIGN="center">

  <form action="<?php echo e(route('login')); ?>" method="POST">
  
  <?php echo csrf_field(); ?> 
  
    
   <div class=" text-center  col-lg-4">
      <br>
      <input type="name" class="form-control" name="name"  id = "name" value="<?php echo e(old('name')); ?>" placeholder="Nombre" >
      <?php echo e($errors->first('name')); ?>

      <br>
      <input type="password" class="form-control"name="password" id= "password" placeholder="Password" >
      <?php echo e($errors->first('password')); ?>

        <br>
        <button type = "submit"class="btn btn-secondary" type="button">INGRESAR</button>
      
    </div>
  </div>

   
  </form>
  
 

  <br><br><br><br><br>
  


  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantillaingreso', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/franco/Documents/pepe/production/new/cems2/resources/views/auth/login.blade.php ENDPATH**/ ?>