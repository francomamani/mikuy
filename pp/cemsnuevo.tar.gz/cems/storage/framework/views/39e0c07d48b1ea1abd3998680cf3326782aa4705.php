<?php $__env->startSection('seccion'); ?>
<br><br>
<?php if(session('mensaje')): ?>
 <div class=" alert alert-success">
  <?php echo e(session('mensaje')); ?>


  <a href="<?php echo e(route('reportem')); ?>" class="btn btn-btn btn-danger btn-sm ">aceptar</a>

 </div >
 
<?php endif; ?>


<h3 ALIGN="center">BUSQUEDA POR CODIGO DE MALETAS RECEPCIONADAS   <h3>
<br><br>


<div ALIGN="center">

  <form action="<?php echo e(route('buscarm')); ?>" method="POST">
  
  <?php echo csrf_field(); ?> 
  <div class="col-lg-6",>
   <div class="input-group card-footer text-center">
      <input type="int" class="form-control"name="CodigoMesa" placeholder="Codigo de Mesa" >
      <span class="input-group-btn">
        <button type = "submit"class="btn btn-warning" type="button">BUSCAR</button>
      </span>
    </div>
  </div>
</div>
    
  </form>
  </div>
  <br><br>
  <div ALIGN="center" >
  <button  onclick="location.href='<?php echo e(route('exportar')); ?>'" ><img src="<?php echo e(asset('Excel.jpg')); ?>" />Exportar  maletas registradas por codigo</button>
  <br><br><br>
  
  </div>

  <?php $__env->stopSection(); ?>
<?php echo $__env->make('plantillamaleta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\proyectos\cems2\resources\views/reportemcodigo.blade.php ENDPATH**/ ?>