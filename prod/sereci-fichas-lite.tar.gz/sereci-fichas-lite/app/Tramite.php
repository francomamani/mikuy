<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Tramite extends Model
{
    use SoftDeletes;

    protected $table = "tramites";
    protected $fillable = [
        'ficha_id',
        'cajero_id',
        'estado',
    ];
    protected $dates = ['deleted_at'];
    protected $appends = [
        'ficha',
        'cajero',
        'categoria_tramite'
    ];

    public function getFichaAttribute()
    {
        return Ficha::find($this->ficha_id);
    }

    public function getCajeroAttribute()
    {
        return Cajero::find($this->cajero_id);
    }

    public function getCategoriaTramiteAttribute()
    {
        return CategoriaTramite::find($this->categoria_tramite_id);
    }
}
