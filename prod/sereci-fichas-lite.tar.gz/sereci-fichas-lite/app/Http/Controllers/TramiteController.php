<?php

namespace App\Http\Controllers;

use App\Cajero;
use App\Ficha;
use App\Tramite;
use App\User;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;
use JWTAuth;

class TramiteController extends Controller
{
    public function index()
    {
        return response()->json(Tramite::orderBy('id', 'desc')->get(), 200);
    }

    public function show($id)
    {
        return response()->json(Tramite::find($id), 200);
    }

    public function store()
    {
        $tramite_data = [
            'ficha_id' => request()->input('ficha_id'),
            'cajero_id' => User::find(JWTAuth::toUser()->id)->cajero()->first()->id,
            'estado' => 'activo',
        ];
        $tramite = Tramite::create($tramite_data);
        /*   $data = [
               'ventanilla_id' => request()->input('ventanilla_id'),
               'tramite_id' => $tramite->id,
               'estado_tramite' => 'procesando',
           ];
           RecepcionTramite::create($data);*/
        return response()->json($tramite, 201);
    }

    /*
     * Permite cambiar el estado de trámite a finalizado
     * body
     *      tramite_id: number
     * */
    public function finalizarTramite()
    {
        $tramite_id = request()->input('tramite_id');
        $tramite = Tramite::find($tramite_id);
/*        $ficha = Ficha::find($tramite['ficha_id']);
        $ficha->estado_ficha = 'atendido';
        $ficha->save();*/
        $tramite->estado = 'finalizado';
        $tramite->save();
        return response()->json($tramite, 200);
    }

    public function miTramite()
    {
        $hoy = Carbon::now()->toDateString();
        $cajero_id = User::find(JWTAuth::toUser()->id)->cajero()->first()->id;
        $tramiteExiste = Tramite::where('cajero_id', '=', $cajero_id)
            ->where('estado', '=', 'activo')
            ->whereDate('created_at', '=', $hoy)
            ->orderByDesc('id')
            ->exists();
        if ($tramiteExiste) {
            $tramite = Tramite::where('cajero_id', $cajero_id)
                ->where('estado', '=', 'activo')
                ->whereDate('created_at', '=', $hoy)
                ->orderByDesc('id')
                ->first();
            return [
                'status' => 200,
                'body' => $tramite,
            ];
        } else {
            return [
                'status' => 404,
                'body' => null,
            ];
        }
    }

    public function update($id)
    {
        $tramite = Tramite::find($id);
        $tramite->update(request()->all());
        return response()->json($tramite, 200);
    }

    public function destroy($id)
    {
        $tramite = Tramite::find($id);
        $tramite->delete();
        return response()->json(['exito' => 'Tramite eliminado con id: ' . $tramite->id], 200);
    }

    public function exportarReporte()
    {
        $input = request()->all();
        $tramites = Tramite::select(DB::raw('count(*) as cantidad, cajero_id'))
            ->whereDate('created_at', '=', $input['fecha'])
            ->groupBy('cajero_id')
            ->get()->toArray();
        $total = Tramite::whereDate('created_at', '=', $input['fecha'])->count();
        $response = [
            'datos' => [],
            'detalles' => []
        ];
        $fecha = explode('-', $input['fecha']);
        $fechaFinal = "{$fecha[2]}/{$fecha[1]}/{$fecha[0]}";
        array_push($response['detalles'], [
            'fecha' => $fechaFinal,
            'total' => $total
        ]);
        foreach ($tramites as $tramite) {
            $cajero = User::find(Cajero::find($tramite['cajero_id'])['user_id']);
            array_push($response['datos'], [
                'cajero' => $cajero['nombres'] . ' ' . $cajero['apellidos'],
                'cantidad' => $tramite['cantidad'],
                'fecha' => $fechaFinal
            ]);
        }
        return response()->json($response, 200);
    }
}
