<?php

namespace App\Http\Controllers;

use App\AsignacionVentanilla;
use App\Cajero;
use App\User;
use JWTAuth;

class CajeroController extends Controller
{
    public function index()
    {
        return response()->json(Cajero::with('user')->orderByDesc('id')->get());
    }

    public function show($id)
    {
        return response()->json(Cajero::find($id), 200);
    }

    public function store()
    {
        $cajero = Cajero::create(request()->all());
        return response()->json($cajero, 201);
    }

    public function update($id)
    {
        $cajero = Cajero::find($id);
        $cajero->update(request()->all());
        return response()->json($cajero, 200);
    }

    public function destroy($id)
    {
        $cajero = Cajero::find($id);
        $cajero->delete();
        return response()->json(['exito' => 'Cajero eliminado con id: ' . $cajero->id], 200);
    }

    public function cajerosUser()
    {
        return response()->json(User::has('cajero')->orderBy('nombres', 'asc')->get());
    }

    public function getAsignacionVentanillas()
    {
        $user = JWTAuth::toUser();
        $asignacion_ventanillas = User::find($user->id)->cajero()->first()
            ->asignacionVentanillas()
            ->with('ventanilla')
            ->where('activo', true)
            ->get();
        return response()->json($asignacion_ventanillas, 200);
    }

    public function miVentanilla()
    {
        $user_id = JWTAuth::toUser()->id;
        $cajero_id = Cajero::where('user_id', (int)$user_id)->first()->id;
        $existe = AsignacionVentanilla::where('cajero_id', $cajero_id)
            ->where('activo', 1)
            ->exists();
        if ($existe) {
            $asignacionVentanilla = AsignacionVentanilla::where('cajero_id', $cajero_id)
                ->where('activo', 1)
                ->first();
            return response()->json([
                'status' => 200,
                'body' => $asignacionVentanilla
            ], 200);
        } else {
            return response()->json([
                'status' => 404,
                'body' => null
            ], 200);
        }
    }

}
